#!/usr/bin/env python3
"""
Test script to check which D&D fonts are available
"""

import os
from generate_statblocks import load_dnd_font

def test_font_loading():
    print("=== D&D Font Loading Test ===\n")
    
    font_types = [
        ("title", "Nodesto Caps Condensed", "Monster names & section headers"),
        ("subtitle", "Mr Eaves Small Caps", "Creature type line"),
        ("label", "Bookinsanity Bold", "Labels (AC, HP, etc.)"),
        ("body", "Bookinsanity Regular", "Main text content"),
        ("ability", "Scaly Sans", "Ability score table"),
    ]
    
    all_authentic = True
    
    for font_type, expected_name, usage in font_types:
        try:
            font = load_dnd_font(font_type, 20)
            # Try to get the font name if possible
            font_name = getattr(font, 'path', 'Unknown system font')
            if 'times.ttf' in str(font_name).lower() or 'arial.ttf' in str(font_name).lower():
                print(f"❌ {font_type:8} → Using fallback font (need {expected_name})")
                all_authentic = False
            else:
                print(f"✅ {font_type:8} → {expected_name} loaded successfully")
        except Exception as e:
            print(f"❌ {font_type:8} → Error: {e}")
            all_authentic = False
    
    print(f"\n=== Font Directory ===")
    if os.path.exists('fonts'):
        font_files = [f for f in os.listdir('fonts') if f.endswith(('.ttf', '.otf'))]
        if font_files:
            print("Found font files:")
            for f in font_files:
                print(f"  • {f}")
        else:
            print("❌ No .ttf or .otf files found in fonts/ directory")
    else:
        print("❌ fonts/ directory doesn't exist")
    
    print(f"\n=== Summary ===")
    if all_authentic:
        print("🎉 All authentic D&D fonts are working!")
    else:
        print("⚠️  Using fallback fonts. See fonts/README.md for setup instructions.")
    
    return all_authentic

if __name__ == "__main__":
    test_font_loading()


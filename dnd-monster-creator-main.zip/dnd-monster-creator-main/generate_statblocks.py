# D&D Monster Statblock Generator
# 
# This script generates printable D&D-style monster statblocks (PNG + PDF) 
# from JSON data and monster illustrations.
#
# Usage:
#   python generate_statblocks.py --text-dir prompts/text --images-dir assets/images --out-dir out
#
# The script will:
# 1. Load all JSON files from the text directory
# 2. Find matching images by filename in the images directory
# 3. Generate PNG and PDF statblocks in the output directory

from PIL import Image, ImageDraw, ImageFont, ImageOps
import textwrap
import json
import os
import argparse
import glob

# -----------------------------
# Utilities
# -----------------------------

def load_dnd_font(font_type, size):
    """
    Load authentic D&D fonts based on their specific use case.
    Falls back to system fonts if D&D fonts aren't available.
    """
    candidates = []
    
    if font_type == "title":  # Monster names, section headers
        candidates = [
            "Nodesto Caps Condensed.ttf",
            "Nodesto Caps Condensed.otf", 
            "./fonts/Nodesto Caps Condensed.ttf",
            "./fonts/Nodesto Caps Condensed.otf",
            "C:/Windows/Fonts/times.ttf",  # Fallback
        ]
    elif font_type == "subtitle":  # Creature type & alignment
        candidates = [
            "Mr Eaves Small Caps.ttf",
            "Mr Eaves Small Caps.otf",
            "./fonts/Mr Eaves Small Caps.ttf", 
            "./fonts/Mr Eaves Small Caps.otf",
            "C:/Windows/Fonts/times.ttf",  # Fallback
        ]
    elif font_type == "label":  # Labels like "Armor Class"
        candidates = [
            "Bookinsanity Bold.ttf",
            "Bookinsanity Bold.otf",
            "./fonts/Bookinsanity Bold.ttf",
            "./fonts/Bookinsanity Bold.otf", 
            "C:/Windows/Fonts/timesbd.ttf",  # Fallback
        ]
    elif font_type == "body":  # Main text content
        candidates = [
            "Bookinsanity.ttf",
            "Bookinsanity Regular.ttf", 
            "Bookinsanity.otf",
            "./fonts/Bookinsanity.ttf",
            "./fonts/Bookinsanity.otf",
            "./fonts/Bookinsanity Regular.ttf",
            "fonts/Bookinsanity.otf",
            "fonts/Bookinsanity.ttf",
            "C:/Windows/Fonts/times.ttf",  # Fallback
        ]
    elif font_type == "ability":  # Ability scores table
        candidates = [
            "Scaly Sans.ttf",
            "Scaly Sans Caps.ttf", 
            "Scaly Sans.otf", 
            "./fonts/Scaly Sans.ttf",
            "./fonts/Scaly Sans.otf",
            "./fonts/Scaly Sans Caps.ttf",
            "fonts/Scaly Sans.otf",
            "fonts/Scaly Sans.ttf",
            "C:/Windows/Fonts/arial.ttf",  # Fallback
        ]
    else:  # Default fallback
        candidates = [
            "Bookinsanity.ttf",
            "C:/Windows/Fonts/times.ttf",
        ]
    
    for path in candidates:
        try:
            if os.path.exists(path):
                return ImageFont.truetype(path, size=size)
        except:
            continue
    
    # Try to load default font with size
    try:
        return ImageFont.load_default()
    except:
        return ImageFont.load_default()

def load_font(size, bold=False):
    """Legacy function for compatibility - use load_dnd_font instead"""
    if bold:
        return load_dnd_font("label", size)
    else:
        return load_dnd_font("body", size)

def draw_text_box(draw, text, xy, box_w, font, line_spacing=8, fill=(20,20,20)):
    """
    Draw wrapped text within a fixed-width box.
    Returns the bottom Y after drawing.
    """
    words = text.split()
    lines = []
    line = ""
    for w in words:
        test = (line + " " + w).strip()
        try:
            w_px = draw.textlength(test, font=font)
        except:
            # Fallback for older Pillow versions
            w_px = draw.textsize(test, font=font)[0]
        
        if w_px <= box_w:
            line = test
        else:
            if line:
                lines.append(line)
            line = w
    if line:
        lines.append(line)

    x, y = xy
    for ln in lines:
        draw.text((x, y), ln, font=font, fill=fill)
        try:
            line_height = font.size
        except:
            line_height = draw.textsize("A", font=font)[1]
        y += line_height + line_spacing
    return y

def hr(draw, x1, x2, y, color=(177, 135, 82), width=2):
    """Draw a horizontal rule/divider bar like D&D 5e style"""
    draw.line([(x1, y), (x2, y)], fill=color, width=width)

def small_caps(text):
    return text.upper()

# -----------------------------
# Renderer
# -----------------------------

def render_statblock(data, art_path, out_png="./out/monster_statblock.png", out_pdf="./out/monster_statblock.pdf"):
    # Create output directory if it doesn't exist
    os.makedirs(os.path.dirname(out_png), exist_ok=True)
    
    # Page setup (pixels)
    W, H = 1654, 2339  # ~A4 at 150 DPI
    margin = 80
    col_gap = 40
    left_col_w = 900
    right_col_w = W - margin*2 - left_col_w - col_gap

    # Colors - Authentic D&D 5e Style
    bg = (241, 231, 214)          # Parchment background
    accent = (132, 87, 50)        # Brown for headers
    gold_bar = (177, 135, 82)     # Golden brown divider bars
    border = (132, 87, 50)        # Brown borders
    ink = (35, 31, 32)            # Dark text
    light_text = (101, 77, 67)    # Lighter brown text

    # Fonts - Much larger sizes to fill space properly
    title_f = load_dnd_font("title", 72)        # Nodesto Caps Condensed for monster names
    sub_f = load_dnd_font("subtitle", 32)       # Mr Eaves Small Caps for creature type
    label_f = load_dnd_font("label", 34)        # Bookinsanity Bold for labels
    body_f = load_dnd_font("body", 30)          # Bookinsanity Regular for text
    ability_f = load_dnd_font("ability", 28)    # Scaly Sans for ability scores
    small_f = load_dnd_font("body", 24)         # Bookinsanity for footer

    # Canvas
    img = Image.new("RGB", (W, H), bg)
    draw = ImageDraw.Draw(img)

    # Decorative border - subtle D&D style
    draw.rectangle([margin-15, margin-15, W-margin+15, H-margin+15], outline=border, width=3)

    # Artwork on right with border fade effect
    if art_path and os.path.exists(art_path):
        try:
            art = Image.open(art_path).convert("RGBA")
            # fit and crop to the right column
            target_h = int(H*0.55)
            target_w = right_col_w
            art = ImageOps.contain(art, (target_w, target_h))
            
            # Create fade mask for all edges (not just left)
            fade_width = 40  # Width of fade effect
            alpha = Image.new("L", art.size, 255)
            
            # Apply fade to all four edges
            for y in range(art.height):
                for x in range(art.width):
                    # Calculate distance from each edge
                    left_dist = x
                    right_dist = art.width - x - 1
                    top_dist = y
                    bottom_dist = art.height - y - 1
                    
                    # Find minimum distance to any edge
                    min_edge_dist = min(left_dist, right_dist, top_dist, bottom_dist)
                    
                    # Apply fade based on distance from edge
                    if min_edge_dist < fade_width:
                        fade_factor = min_edge_dist / fade_width
                        alpha_value = int(255 * fade_factor)
                    else:
                        alpha_value = 255
                    
                    alpha.putpixel((x, y), alpha_value)
            
            art.putalpha(alpha)
            art_x = margin + left_col_w + col_gap
            art_y = margin
            # paste with alpha blending
            img.paste(art, (art_x, art_y), art)
        except Exception as e:
            print(f"Warning: Could not load artwork from {art_path}: {e}")

    # Header title
    name = data.get("name", "Unknown Creature")
    type_line = f'{data.get("size","Medium")} {data.get("type","monstrosity")}, {data.get("alignment","unaligned")}'
    draw.text((margin, margin), name, font=title_f, fill=ink)
    
    try:
        title_height = title_f.size
        sub_height = sub_f.size
    except:
        title_height = draw.textsize(name, font=title_f)[1]
        sub_height = draw.textsize(type_line, font=sub_f)[1]
    
    draw.text((margin, margin + title_height + 6), type_line, font=sub_f, fill=(60,60,60))
    y = margin + title_height + sub_height + 24

    # Start stats section - no background panel
    y += 15
    x = margin

    # AC / HP / Speed
    def kv(label, value):
        nonlocal y
        draw.text((x, y), small_caps(label), font=label_f, fill=accent)
        try:
            label_height = label_f.size
        except:
            label_height = draw.textsize(label, font=label_f)[1]
        y += label_height + 2
        y = draw_text_box(draw, str(value), (x, y), left_col_w, body_f, line_spacing=6, fill=ink) + 8

    kv("Armor Class", data.get("ac", ""))
    kv("Hit Points", data.get("hp", ""))
    kv("Speed", data.get("speed", ""))

    # Ability scores
    y += 8
    hr(draw, margin, margin+left_col_w, y, color=gold_bar, width=2); y += 15
    ability_labels = ["STR","DEX","CON","INT","WIS","CHA"]
    ability_values = data.get("abilities", {"STR":"10 (+0)","DEX":"10 (+0)","CON":"10 (+0)","INT":"10 (+0)","WIS":"10 (+0)","CHA":"10 (+0)"})
    cell_w = left_col_w // 6
    
    try:
        ability_label_height = ability_f.size
        ability_value_height = ability_f.size
    except:
        ability_label_height = draw.textsize("STR", font=ability_f)[1]
        ability_value_height = draw.textsize("10 (+0)", font=ability_f)[1]
    
    for i, lab in enumerate(ability_labels):
        cx = margin + i*cell_w
        draw.text((cx, y), lab, font=ability_f, fill=accent)
        draw.text((cx, y + ability_label_height + 2), str(ability_values.get(lab, "")), font=ability_f, fill=ink)
    y += ability_label_height + ability_value_height + 18
    hr(draw, margin, margin+left_col_w, y, color=gold_bar, width=2); y += 15

    # Traits (saving throws, skills, senses, etc.)
    misc_fields = [
        ("Saving Throws", data.get("saving_throws","")),
        ("Skills", data.get("skills","")),
        ("Senses", data.get("senses","")),
        ("Languages", data.get("languages","—")),
        ("Challenge", data.get("challenge","")),
    ]
    for label, value in misc_fields:
        if value:
            draw.text((x, y), small_caps(label), font=label_f, fill=accent)
            try:
                label_height = label_f.size
            except:
                label_height = draw.textsize(label, font=label_f)[1]
            y = draw_text_box(draw, str(value), (x, y + label_height + 2), left_col_w, body_f) + 8

    # Traits/Features list
    traits = data.get("traits", [])
    if traits:
        y += 8
        hr(draw, margin, margin+left_col_w, y, color=gold_bar, width=2); y += 15
        for t in traits:
            title = t.get("name","").strip()
            text = t.get("text","").strip()
            if title:
                draw.text((x, y), f"{title}.", font=label_f, fill=accent)
                try:
                    label_height = label_f.size
                except:
                    label_height = draw.textsize(title, font=label_f)[1]
                y += label_height + 2
            y = draw_text_box(draw, text, (x, y), left_col_w, body_f) + 8

    # Actions section
    y += 12
    hr(draw, margin, margin+left_col_w, y, color=gold_bar, width=2); y += 8
    draw.text((margin, y), "ACTIONS", font=label_f, fill=accent)
    try:
        label_height = label_f.size
    except:
        label_height = draw.textsize("ACTIONS", font=label_f)[1]
    y += label_height + 8
    actions = data.get("actions", [])
    for a in actions:
        a_title = a.get("name","").strip()
        a_text = a.get("text","").strip()
        if a_title:
            draw.text((margin, y), a_title, font=label_f, fill=ink)
            try:
                label_height = label_f.size
            except:
                label_height = draw.textsize(a_title, font=label_f)[1]
            y += label_height + 2
        y = draw_text_box(draw, a_text, (margin, y), left_col_w, body_f) + 12

    # Right column text (lore/description) - position text immediately after image
    right_x = margin + left_col_w + col_gap
    if art_path and os.path.exists(art_path):
        # Calculate where the image actually ends and position text right after
        try:
            art = Image.open(art_path).convert("RGBA")
            target_h = int(H*0.55)
            target_w = right_col_w
            art_resized = ImageOps.contain(art, (target_w, target_h))
            actual_image_height = art_resized.height
            right_y = art_y + actual_image_height + 20  # Small gap after actual image
        except:
            # Fallback if image processing fails
            right_y = art_y + int(H*0.35) + 20
    else:
        right_y = margin
    
    lore_title = data.get("lore_title", name)
    lore = data.get("lore", "")
    if lore:
        draw.text((right_x, right_y), lore_title, font=label_f, fill=accent)
        try:
            label_height = label_f.size
        except:
            label_height = draw.textsize(lore_title, font=label_f)[1]
        right_y += label_height + 10
        right_y = draw_text_box(draw, lore, (right_x, right_y), right_col_w, body_f)

    # Footer
    footer = data.get("attribution", "Homebrew sheet generated with Python (Pillow).")
    try:
        small_height = small_f.size
    except:
        small_height = draw.textsize(footer, font=small_f)[1]
    draw.text((margin, H - margin - small_height), footer, font=small_f, fill=(90,90,90))

    # Save outputs
    img.save(out_png, "PNG")
    print(f"PNG saved to: {out_png}")
    
    try:
        img.convert("RGB").save(out_pdf, "PDF", resolution=150.0)
        print(f"PDF saved to: {out_pdf}")
    except Exception as e:
        print(f"Warning: Could not save PDF: {e}")
        
    return out_png, out_pdf

# -----------------------------
# File Processing Functions
# -----------------------------

def find_matching_image(json_filename, images_dir):
    """Find a matching image file for a given JSON filename."""
    if not images_dir or not os.path.exists(images_dir):
        return None
    
    base_name = os.path.splitext(json_filename)[0]
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp']
    
    for ext in image_extensions:
        image_path = os.path.join(images_dir, base_name + ext)
        if os.path.exists(image_path):
            return image_path
    
    return None

def load_monster_json(json_path):
    """Load and validate monster data from JSON file."""
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data
    except Exception as e:
        print(f"Error loading {json_path}: {e}")
        return None

def process_monsters(text_dir, images_dir, out_dir):
    """Process all monster JSON files in the text directory."""
    if not os.path.exists(text_dir):
        print(f"Error: Text directory '{text_dir}' does not exist")
        return
    
    # Ensure output directory exists
    os.makedirs(out_dir, exist_ok=True)
    
    # Find all JSON files
    json_files = glob.glob(os.path.join(text_dir, "*.json"))
    
    if not json_files:
        print(f"No JSON files found in '{text_dir}'")
        return
    
    print(f"Found {len(json_files)} monster files to process...")
    
    for json_file in json_files:
        print(f"\nProcessing: {os.path.basename(json_file)}")
        
        # Load monster data
        monster_data = load_monster_json(json_file)
        if not monster_data:
            continue
        
        # Find matching image
        json_filename = os.path.basename(json_file)
        image_path = find_matching_image(json_filename, images_dir)
        if image_path:
            print(f"  Found image: {os.path.basename(image_path)}")
        else:
            print(f"  No matching image found")
        
        # Generate output paths
        base_name = os.path.splitext(json_filename)[0]
        out_png = os.path.join(out_dir, f"{base_name}.png")
        out_pdf = os.path.join(out_dir, f"{base_name}.pdf")
        
        # Generate statblock
        try:
            render_statblock(monster_data, image_path, out_png, out_pdf)
            print(f"  ✓ Generated: {base_name}.png and {base_name}.pdf")
        except Exception as e:
            print(f"  ✗ Error generating statblock: {e}")

# -----------------------------
# Command Line Interface
# -----------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Generate D&D monster statblocks from JSON and images",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python generate_statblocks.py --text-dir prompts/text --images-dir assets/images --out-dir out
  python generate_statblocks.py --text-dir prompts/text --out-dir out  # without images
        """
    )
    
    parser.add_argument("--text-dir", required=True,
                       help="Directory containing monster JSON files")
    parser.add_argument("--images-dir", 
                       help="Directory containing monster images (optional)")
    parser.add_argument("--out-dir", default="out",
                       help="Output directory for generated statblocks (default: out)")
    
    args = parser.parse_args()
    
    process_monsters(args.text_dir, args.images_dir, args.out_dir)

if __name__ == "__main__":
    main()

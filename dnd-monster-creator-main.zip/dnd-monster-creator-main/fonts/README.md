# D&D Fonts Setup

To get the most authentic D&D 5e statblock appearance, place these font files in this `fonts/` directory:

## Required D&D Fonts

### 📝 **Primary Fonts**
- **Nodesto Caps Condensed** (.ttf or .otf)
  - Used for: Monster names, section headers (ACTIONS, etc.)
  - The iconic tall, narrow caps used in official D&D books

- **Bookinsanity** (.ttf or .otf) 
  - Bookinsanity Regular - Main body text
  - Bookinsanity Bold - Labels (Armor Class, Hit Points, etc.)
  - Bookinsanity Italic - Emphasis text
  - The main text font for D&D 5e statblocks

### 📊 **Specialized Fonts**
- **Mr Eaves Small Caps** (.ttf or .otf)
  - Used for: Creature type line (Large monstrosity, chaotic evil)

- **Scaly Sans** / **Scaly Sans Caps** (.ttf or .otf)
  - Used for: Ability score tables (STR, DEX, CON, etc.)
  - Clean sans-serif for tabular data

### 🎨 **Optional Decorative Fonts**
- **Zatanna Misdirection** - Monster quotes/flavor text
- **Solbera Imitation** - Drop caps and decorative initials

## Installation

1. Download the D&D fonts from their respective sources
2. Place the .ttf or .otf files directly in this `fonts/` directory
3. Run the generator - it will automatically detect and use them!

## Fallback Behavior

If D&D fonts aren't available, the generator will use:
- **Times New Roman** for most text (good serif fallback)
- **Arial** for ability scores (sans-serif fallback)

The output will still look good, but authentic D&D fonts give the true official appearance!

## Font File Names

The script looks for these exact filenames:
- `Nodesto Caps Condensed.ttf` (or .otf)
- `Bookinsanity.ttf` (or .otf)  
- `Bookinsanity Bold.ttf` (or .otf)
- `Mr Eaves Small Caps.ttf` (or .otf)
- `Scaly Sans.ttf` (or .otf)
- `Scaly Sans Caps.ttf` (or .otf)

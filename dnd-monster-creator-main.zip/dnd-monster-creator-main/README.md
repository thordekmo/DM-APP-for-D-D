# D&D Monster Statblock Generator

This project generates printable D&D-style monster statblocks (PNG + PDF) from JSON data and monster illustrations.

## Workflow
1. **Create monster JSON**  
   - Write a file in `prompts/text` using `templates/monster_template.json` as a guide.
   - You can also generate it by giving `templates/text_prompt_template.md` to an LLM.

2. **Create/Generate an image**  
   - Place the illustration in `assets/images/`.
   - Optionally, generate it from `templates/image_prompt_template.md`.

3. **Run the generator**  
   ```bash
   python generate_statblocks.py --text-dir prompts/text --images-dir assets/images --out-dir out
   ```

4. **Output**  
   - Final PNG + PDF files are saved in `out/`.

## Notes
- JSON and image are matched by filename (or via `art_path` field in JSON).
- Script uses only Pillow (no heavy dependencies).
- You can freely customize fonts, colors, and layout inside the script.
